from django.contrib import admin

from .models import  DSO, BSS


admin.site.register(DSO)
admin.site.register(BSS)
# Register your models here.
