from django.contrib import admin
from .models import Socket
admin.site.register(Socket)
# Register your models here.
