from django.contrib import admin
from ChargingStation.models import ChargingStation

# Register your models here.
admin.site.register(ChargingStation)