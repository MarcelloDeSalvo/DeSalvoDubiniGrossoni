from django.apps import AppConfig


class ChargingstationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ChargingStation'
