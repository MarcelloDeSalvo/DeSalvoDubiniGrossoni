from django.contrib import admin
from .models import Discount

admin.site.register(Discount)
# Register your models here.
