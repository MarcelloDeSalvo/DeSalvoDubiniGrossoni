import CpmsNav from '~/components/CpmsNav.vue'
<template>
    <div>
      <CpmsNav />
      <slot />
    </div>
</template>

      


