import EmspNav from '~/components/EmspNav.vue'

<template>
    <div>
      <EmspNav />
      <slot />
    </div>
</template>

