import NavBar from '../components/NavBar.vue';

<template>
    <div>
      <NavBar />
      <slot />
    </div>
</template>

