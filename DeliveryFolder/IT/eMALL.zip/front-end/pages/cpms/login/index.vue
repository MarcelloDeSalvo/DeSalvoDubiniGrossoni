<template>
  <div>
    <div class="flex">
      <div class="min-h-screen flex-1">
        <div class="flex h-full items-center py-8 px-5">
          <CPMSLoginForm />
        </div>
      </div>
      <div class="hidden min-h-screen flex-1 bg-gray-50 px-5 py-5 lg:flex">
        <div class="mx-auto flex h-full items-center">
          <NuxtLogo />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import CPMSLoginForm from '~/components/CPMSLoginForm.vue'

  definePageMeta({
    middleware: ['cpms-auth']
  })
</script>