<template>
    <div class="px-4 py-16 mx-auto sm:max-w-xl md:max-w-full lg:max-w-screen-xl md:px-24 lg:px-8 lg:py-20">
      <div class="grid max-w-2xl mx-auto">
        <div class="flex">
          <div class="flex flex-col items-center mr-6">
            <div class="w-px h-10 opacity-0 sm:h-full"></div>
            <div>
              <div class="flex items-center justify-center w-8 h-8 text-xs font-medium border rounded-full">
                1
              </div>
            </div>
            <div class="w-px h-full bg-gray-300"></div>
          </div>
          <div class="flex flex-col pb-6 sm:items-center sm:flex-row sm:pb-0">
            <div class="sm:mr-5">
              <div class="flex items-center justify-center w-16 h-16 my-3 rounded-full bg-indigo-50 sm:w-24 sm:h-24">
                <svg width="16" height="16" fill="currentColor" class="w-12 h-12 text-deep-purple-accent-400 sm:w-19 sm:h-19" viewBox="0 -4 16 24"> 
                  <path d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A31.493 31.493 0 0 1 8 14.58a31.481 31.481 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94zM8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10z"/> <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4zm0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/> 
                </svg>
              </div>
            </div>
            <div>
              <p class="text-xl font-semibold sm:text-base">View the nearest charging stations</p>
              <p class="text-sm text-gray-700">
                Our service is supported by various charging stations' operators, so you can always find one near you.
              </p>
            </div>
          </div>
        </div>
        <div class="flex">
          <div class="flex flex-col items-center mr-6">
            <div class="w-px h-10 bg-gray-300 sm:h-full"></div>
            <div>
              <div class="flex items-center justify-center w-8 h-8 text-xs font-medium border rounded-full">
                2
              </div>
            </div>
            <div class="w-px h-full bg-gray-300"></div>
          </div>
          <div class="flex flex-col pb-6 sm:items-center sm:flex-row sm:pb-0">
            <div class="sm:mr-5">
              <div class="flex items-center justify-center w-16 h-16 my-3 rounded-full bg-indigo-50 sm:w-24 sm:h-24">
                <svg width="16" height="16" fill="currentColor" class="w-12 h-12 text-deep-purple-accent-400 sm:w-19 sm:h-19" viewBox="0 -3 16 24">
                  <path fill-rule="evenodd" d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"/> <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z"/>
                </svg>
              </div>
            </div>
            <div>
              <p class="text-xl font-semibold sm:text-base">Book the perfect charging session</p>
              <p class="text-sm text-gray-700">
                With our booking service you won't ever need to worry about finding an available charging spot, just book it!<!-- We can even suggest the best time and location for you! --> 
              </p>
            </div>
          </div>
        </div>
        <div class="flex">
          <div class="flex flex-col items-center mr-6">
            <div class="w-px h-10 bg-gray-300 sm:h-full"></div>
            <div>
              <div class="flex items-center justify-center w-8 h-8 text-xs font-medium border rounded-full">
                3
              </div>
            </div>
            <div class="w-px h-full opacity-0"></div>
          </div>
          <div class="flex flex-col pb-6 sm:items-center sm:flex-row sm:pb-0">
            <div class="sm:mr-5">
              <div class="flex items-center justify-center w-16 h-16 my-3 rounded-full bg-indigo-50 sm:w-24 sm:h-24">
                <svg class="w-12 h-12 text-deep-purple-accent-400 sm:w-19.5 sm:h-19.5" width="20" height="20" viewBox="2 1 19 24" stroke-width="1" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
                  <path stroke="none" d="M0 0h24v24H0z" fill="none"/> <path d="M4 9a2 2 0 0 1 2 -2h11a2 2 0 0 1 2 2v.5a0.5 .5 0 0 0 .5 .5a0.5 .5 0 0 1 .5 .5v3a0.5 .5 0 0 1 -.5 .5a0.5 .5 0 0 0 -.5 .5v.5a2 2 0 0 1 -2 2h-4.5" /> <path d="M3 15h6v2a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2v-2z" /> <path d="M6 22v-3" /> <path d="M4 15v-2.5" /> <path d="M8 15v-2.5" />
                </svg>
              </div>
            </div>
            <div>
              <p class="text-xl font-semibold sm:text-base">Start your charging session</p>
              <p class="text-sm text-gray-700">
                No more need for multiple apps, with our service you can start, stop and pay for any charging session you need.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>