<template>
  <a
    href="https://nuxtjs.org"
    target="_blank"
    class="flex justify-center pt-8 sm:pt-0"
    >
    <img
      src="/img/concept.png"
      alt="Nuxt.js"
      class="w-150"
      />
  </a>
</template>
